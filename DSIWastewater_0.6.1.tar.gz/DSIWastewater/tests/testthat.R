library(testthat)
test_check("DSIWastewater")
