library(devtools)

document()
build_vignettes()
build()
install()

