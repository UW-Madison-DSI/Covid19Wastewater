## ----setup, include=FALSE-----------------------------------------------------
knitr::opts_chunk$set(echo = TRUE, eval = FALSE)
library(dplyr)
library(ggplot2)


## -----------------------------------------------------------------------------
#  data("WasteWater_data", package = "Covid19Wastewater")
#  
#  WasteWater_data %>% ggplot(aes(x=date,y=N1)) +
#    geom_point()

## -----------------------------------------------------------------------------
#  data("WasteWater_data", package = "Covid19Wastewater")
#  
#  WasteWater_data %>% ggplot() +
#    geom_point(aes(x=date,y=N2+1, color = "N2")) + #plus 1 to have a nice log
#    geom_point(aes(x=date,y=N1+1, color = "N1")) +
#    scale_y_log10() +
#    ylab("N1 and N2")

## -----------------------------------------------------------------------------
#  data("WasteWater_data", package = "Covid19Wastewater")
#  data("Case_data", package = "Covid19Wastewater")
#  
#  WasteAndCaseMerged_data <- merge(Case_data,WasteWater_data, by = c("site","date"))
#  head(WasteAndCaseMerged_data)

## -----------------------------------------------------------------------------
#  data("HFGWaste_data", package = "Covid19Wastewater")
#  data("HFGCase_data", package = "Covid19Wastewater")
#  
#  HFGWasteAndCaseMerged_data <- merge(HFGCase_data,HFGWaste_data, by = c("site","date"))
#  head(HFGWasteAndCaseMerged_data)

## -----------------------------------------------------------------------------
#  data("WasteWater_data", package = "Covid19Wastewater")
#  data("Aux_info_data", package = "Covid19Wastewater")
#  
#  WastewaterAndAuxInfo_data <- merge(WasteWater_data,Aux_info_data, by = "sample_id")
#  head(WastewaterAndAuxInfo_data)

## -----------------------------------------------------------------------------
#  data("WasteWater_data", package = "Covid19Wastewater")
#  data("Pop_data", package = "Covid19Wastewater")
#  data("Case_data", package = "Covid19Wastewater")
#  
#  WastewaterAndPop_data <- merge(WasteWater_data,Pop_data, by = "site")
#  head(WastewaterAndPop_data)
#  
#  CaseAndPop_data <- merge(Case_data,Pop_data, by = "site")
#  head(CaseAndPop_data)

## -----------------------------------------------------------------------------
#  HFGWasteAndCaseMerged_data %>% ggplot() +
#    geom_point(aes(x=log(N1+1),y=log(ConfirmedCases+1),color="N1")) +
#    geom_point(aes(x=log(N2+1),y=log(ConfirmedCases+1),color="N2")) +
#    facet_wrap("site")

## -----------------------------------------------------------------------------
#  CaseAndPop_data %>% filter(site == "Madison") %>% ggplot(aes(x=date,y=(conf_case/pop)))+
#    geom_point()

## -----------------------------------------------------------------------------
#  data("WasteWater_data", package = "Covid19Wastewater")
#  WasteWater_data  <- filter(WasteWater_data, site == "Janesville")
#  WasteWater_data <- mutate(WasteWater_data, N1 = log(N1 + 1))
#  WasteWater_data <- loessSmoothMod(WasteWater_data , "N1", "N1_loess")
#  WasteWater_data <- Flag_From_Trend(WasteWater_data,  N1, N1_loess)
#  
#  WasteWater_data %>%
#    ggplot(aes(x = date))+
#    geom_point(aes(y = N1, color = flagged_outlier))+
#  geom_line(aes(y = N1_loess, color = "N1 Loess"))+
#    theme(plot.title = element_text(hjust = 0.5),
#          axis.text.x = element_text(angle = 90, vjust = 0.5, hjust=1))+
#    labs(y = "Covid-19 Gene Concentration",
#         x = "Date",
#         color = "Flagged Outlier"
#         )

