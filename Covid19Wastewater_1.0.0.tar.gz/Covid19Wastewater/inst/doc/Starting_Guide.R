## ----setup, include=FALSE-----------------------------------------------------
knitr::opts_chunk$set(echo = TRUE, eval = FALSE)
library(dplyr)
library(ggplot2)


## ---- echo=FALSE, eval = FALSE, fig.align='center'----------------------------
#  knitr::include_graphics("../docs/images/covid-droplet.svg")

## ---- echo=FALSE, eval = TRUE, fig.align='center'-----------------------------
knitr::include_graphics("../docs/images/getting-started/wastewater-process.png")

## ---- echo=FALSE, eval = TRUE, fig.align='center'-----------------------------
knitr::include_graphics("../docs/images/getting-started/wastewater-offset.png")

## ---- echo=FALSE, eval = TRUE, fig.align='center'-----------------------------
knitr::include_graphics("../docs/images/getting-started/sample-frequency.png")

## -----------------------------------------------------------------------------
#  data(<name here>, package = "Covid19Wastewater")

## -----------------------------------------------------------------------------
#  data("WasteWater_data", package = "Covid19Wastewater")
#  
#  WasteWater_data %>% ggplot(aes(x=date,y=N1)) +
#    geom_point()

## ---- echo=FALSE, eval = TRUE, fig.align='center'-----------------------------
knitr::include_graphics("../docs/images/getting-started/n1-n2-levels.png")

## -----------------------------------------------------------------------------
#  data("WasteWater_data", package = "Covid19Wastewater")
#  
#  WasteWater_data %>% ggplot() +
#    geom_point(aes(x=date,y=N2+1, color = "N2")) + #plus 1 to have a nice log
#    geom_point(aes(x=date,y=N1+1, color = "N1")) +
#    scale_y_log10() +
#    ylab("N1 and N2")

## ---- echo=FALSE, eval = TRUE, fig.align='center'-----------------------------
knitr::include_graphics("../docs/images/getting-started/n1-n2-levels-colored.png")

## -----------------------------------------------------------------------------
#  data("WasteWater_data", package = "Covid19Wastewater")
#  data("Case_data", package = "Covid19Wastewater")
#  
#  WasteAndCaseMerged_data <- merge(Case_data, WasteWater_data, by = c("site","date"))
#  head(WasteAndCaseMerged_data)

## ---- echo=FALSE, eval = TRUE, fig.align='center'-----------------------------
knitr::include_graphics("../docs/images/getting-started/wastewater-case-data.png")

## -----------------------------------------------------------------------------
#  data("HFGWaste_data", package = "Covid19Wastewater")
#  data("HFGCase_data", package = "Covid19Wastewater")
#  
#  HFGWasteAndCaseMerged_data <- merge(HFGCase_data,HFGWaste_data, by = c("site","date"))
#  head(HFGWasteAndCaseMerged_data)

## ---- echo=FALSE, eval = TRUE, fig.align='center'-----------------------------
knitr::include_graphics("../docs/images/getting-started/hfg-wastewater-case-data.png")

## -----------------------------------------------------------------------------
#  data("WasteWater_data", package = "Covid19Wastewater")
#  data("Aux_info_data", package = "Covid19Wastewater")
#  
#  WastewaterAndAuxInfo_data <- merge(WasteWater_data,Aux_info_data, by = "sample_id")
#  head(WastewaterAndAuxInfo_data)

## ---- echo=FALSE, eval = TRUE, fig.align='center'-----------------------------
knitr::include_graphics("../docs/images/getting-started/wastewater-aux-data.png")

## -----------------------------------------------------------------------------
#  data("WasteWater_data", package = "CovidWastewater")
#  data("pop_data", package = "Covid19Wastewater")
#  data("Case_data", package = "Covid19Wastewater")
#  
#  WastewaterAndPop_data <- merge(WasteWater_data, pop_data, by = "site")
#  head(WastewaterAndPop_data)
#  
#  CaseAndPop_data <- merge(Case_data, pop_data, by = "site")
#  head(CaseAndPop_data)

## ---- echo=FALSE, eval = TRUE, fig.align='center'-----------------------------
knitr::include_graphics("../docs/images/getting-started/wastewater-pop-data.png")

## -----------------------------------------------------------------------------
#  HFGWasteAndCaseMerged_data %>%
#    ggplot() +
#    geom_point(aes(x=log(N1+1),y=log(ConfirmedCases+1),color="N1")) +
#    geom_point(aes(x=log(N2+1),y=log(ConfirmedCases+1),color="N2")) +
#    facet_wrap("site")

## ---- echo=FALSE, eval = TRUE, fig.align='center'-----------------------------
knitr::include_graphics("../docs/images/getting-started/wastewater-confirmed-cases.png")

## -----------------------------------------------------------------------------
#  CaseAndPop_data %>%
#      filter(site == "Madison") %>%
#      ggplot(aes(x=date,y=(conf_case/pop)))+
#      geom_point()

## ---- echo=FALSE, eval = TRUE, fig.align='center'-----------------------------
knitr::include_graphics("../docs/images/getting-started/confirmed-cases-per-person.png")

## ---- echo=FALSE, eval = TRUE, fig.align='center'-----------------------------
knitr::include_graphics("../docs/images/getting-started/Smoothings.JPG")

## -----------------------------------------------------------------------------
#  WasteWater_flag  <- WasteWater_data%>%
#      filter(site == "Janesville")%>%
#      mutate(N1 = log(N1 + 1))%>%
#      select(site, date, N1)%>%
#      loessSmoothMod("N1", "N1_loess")%>%
#      Flag_From_Trend(N1, N1_loess)
#  
#  WasteWater_flag %>%
#    ggplot(aes(x = date))+
#    geom_point(aes(y = N1, color = flagged_outlier))+
#  geom_line(aes(y = N1_loess, color = "N1 Loess"))+
#    theme(plot.title = element_text(hjust = 0.5),
#          axis.text.x = element_text(angle = 90, vjust = 0.5, hjust=1))+
#    labs(y = "Covid-19 Gene Concentration",
#         x = "Date",
#         color = "Flagged Outlier"
#         )

## ---- echo=FALSE, eval = TRUE, fig.align='center'-----------------------------
knitr::include_graphics("../docs/images/getting-started/Trend_Outlier.png")

## -----------------------------------------------------------------------------
#  WasteWater_data <- WasteWater_data%>%
#    select(site, date, N1, N2)%>%
#    filter(N1 != 0, N2 != 0)%>%
#    mutate(N1 = log(N1), N2 = log(N2),
#      N12_avg = (N1 + N2) / 2)
#  df_data <- computeJumps(WasteWater_data)
#  ranked_data <- rankJumps(df_data)
#  classied_data <- flagOutliers(ranked_quantile_data, 9, MessureRank)%>%
#    select(site, date, N12_avg, MessureRank, FlaggedOutlier)
#  
#  classied_data%>%
#    ggplot(aes(x = date))+
#    geom_point(aes(y = N12_avg, color = FlaggedOutlier))+
#    facet_wrap(~site)+
#    theme(plot.title = element_text(hjust = 0.5),
#          axis.text.x = element_text(angle = 90, vjust = 0.5, hjust=1))+
#    labs(y = "Covid-19 Gene Concentration",
#         x = "Date",
#         color = "Flagged Outlier"
#         )

## ---- echo=FALSE, eval = TRUE, fig.align='center'-----------------------------
knitr::include_graphics("../docs/images/getting-started/Adjacent_Outlier.png")

## ---- echo=FALSE, eval = TRUE, fig.align='center'-----------------------------
knitr::include_graphics("../docs/images/getting-started/time-series-analysis.png")

## ---- echo=FALSE, eval = TRUE, fig.align='center'-----------------------------
knitr::include_graphics("../docs/images/getting-started/offset-analysis.png")

## ---- echo=FALSE, eval = TRUE, fig.align='center'-----------------------------
knitr::include_graphics("../docs/images/getting-started/Random_Forest.png")

