#' random_linear_forest
#' model class using a random forest of linear forest models
#'  
#'
#' @slot formula formula used to create trees and linear models 
#' @slot models list of each tree model in model  
#' @slot data data.frame of the input data
#' @slot resid numeric vector of residuals
#' @slot inbag_data list of data.frame each model trained on
#' @slot oob_data list of data.frame containing info model not trained on 
#' @slot oob_resid numeric vector of oob residuals
#'
#' @return random_linear_forest object
#' @export
#'
#' @examples
#' data("example_data", package = "DSIWastewater")
#' random_linear_forest(example_data, 2, PMMoV ~ N1 + N2 | date + site)
setClass(
  "random_linear_forest",
  slots = list(formula = "formula",
               models = "list",
               data = "data.frame",
               resid = "numeric",
               inbag_data = "list",
               oob_data = "list",
               oob_resid = "numeric")
)


#' Fitting linear random forest
#' 
#' This uses the linear tree model from party kit and bootstrapping
#' to create linear random forests that work like a random forest but with
#' the linear dynamics permuted with a linear method
#'
#' @param data a dataframe containing the variables in the model
#' @param num_tree numeric, the number of trees in the random forest.
#' @param model_formula an object of class "formula": a symbolic description of the model to be fitted. 
#' @param num_features number of tree features in each tree. if left NULL rounded up square of the number of columns
#' @param max_depth the max depth of each tree in the forest
#'
#' @return random_linear_forest object trained using given data
#' @export
#'
#' @examples
#' data("example_data", package = "DSIWastewater")
#' random_linear_forest(PMMoV ~ N1 + N2 | date + site)
random_linear_forest <- function(data,
                                 num_tree,
                                 model_formula,
                                 num_features = NULL,
                                 max_depth = 5,
                                 verbose = FALSE){
  #move formula columns to front
  dep_term <- as.character(model_formula[[2]])
  lm_pred_term <- all.vars(model_formula[[3]][[2]])
  tree_pred_term <- all.vars(model_formula[[3]][[3]])
  data <- select(data, all_of(c(dep_term, 
           lm_pred_term)),
           everything())
  ####
  
  #create random_linear_forest class object the function returns
  linear_forest <- new("random_linear_forest",
                       formula = model_formula,
                       data = data)
  
  
  #create index for linking bagged data back together
  data$index <- 1:nrow(data)
  data <- select(data, index, everything())
  
  #do the Bootstrap aggregating do improve error
  Boot_list_DF <- bagging(data, 
                          num_bags = num_tree,
                          num_features = num_features,
                          include_first = 2 + length(lm_pred_term))
  
  #add data to return object
  linear_forest@inbag_data <- Boot_list_DF[[1]]
  linear_forest@oob_data <- Boot_list_DF[[2]]
  
  #function used for each tree
  lmtree_func <- function(data) {#glmtree
    mod_tree <- lmtree(formula = model_formula,
                       data = select(data, -index),# family = gaussian,
                       na.action = na.pass,
                       maxdepth = max_depth)
    if(verbose){
      print("tree fitted")
    }
    return(mod_tree)
  }
  
  #train the models
  linear_forest@models <- lapply(linear_forest@inbag_data, lmtree_func)
  
  #save residuals
  linear_forest@resid <- data$conf_case - predict(linear_forest, data)
  
  #save out of bag residuals
  #linear_forest@oob_resid <- gen_OOB_pred(linear_forest,
  #                                        resid = TRUE)
  
  return(linear_forest)
}
