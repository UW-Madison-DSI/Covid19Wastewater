## ----setup, include=FALSE-----------------------------------------------------
knitr::opts_chunk$set(echo = TRUE)

## ----load and show data-------------------------------------------------------


## ----explain all / most relavent columns--------------------------------------


## ----explain / show use case and link to other vignettes----------------------

