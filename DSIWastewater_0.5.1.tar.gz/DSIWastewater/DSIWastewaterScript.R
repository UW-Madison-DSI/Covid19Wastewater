
library(devtools)

mach_reg <- function(file_path, match, split){
  file_break = strsplit(file_path, split)[[1]][2]
  return(file_break == match)
}

move_struct_R <- function(start, end = "R", add_context = TRUE, end_in = NA){
  to_move_files <- list.files(path = start, recursive = TRUE)
  
  for(file in to_move_files){
    is_dead = FALSE
    
    if(!is.na(end_in)){
      is_dead = !mach_reg(file, end_in, "\\.")
    }
    
    file_type = strsplit(file, "/")[[1]]
    if(add_context){
      location = paste0(end, "/", start)
      for(sub_folder in file_type){
        location = paste0(location, "--", sub_folder)
        is_dead = sub_folder == "README"
        
      }
      if(!is_dead){
        file.copy(from = paste0(start,"/",file), to = location)
      }
    }else{
      if(!is_dead){
        file.copy(from = paste0(start,"/",file), end)
      }
    }
  }
}

package_update <- function(path = ".", update_examples = F, update_test = F){
  setwd(dirname(rstudioapi::getActiveDocumentContext()$path))
  #setwd(path)
  #file.remove("DSIWastewater_0.5.1.tar.gz")
  #Delete R folder and all .R folders in it
  unlink("R", recursive = T, force = T)
  dir.create("R")
  move_struct_R("library", "R")
  move_struct_R("meta_info", "R", add_context = FALSE)
  
  if(update_examples){#build vignette
    unlink("vignettes", recursive = T, force = T)
    dir.create("vignettes")
    move_struct_R("examples", "vignettes", add_context = FALSE, end_in = "Rmd")
    build_vignettes(quiet = F)
    unlink("docs/vignettes", recursive = T, force = T)
    dir.create("docs/vignettes")
    for(fileName in dir("doc")){
      if(!mach_reg(fileName, "Rmd", "\\.") && !mach_reg(fileName, "R", "\\.")){
        file.copy(paste0("doc/", fileName), paste0("docs/vignettes/", fileName), overwrite=TRUE)
      }
    }
    print("done update")
  }
  
  document()
  build(path = ".", vignettes = F)
  #devtools::install_github("AFIDSI/DSIWastewater")
  
  if(update_examples){
    unlink("doc", recursive = T, force = T)
  }
  
  if(update_test){
    check(args = c("--no-tests"), vignettes = FALSE)
    test()
  }
  install(quick=T, build = T, build_vignettes = T, force = T)
}
package_update(update_examples = T, update_test = F)