## ----load packages------------------------------------------------------------
library(DSIWastewater)

## ----create worksheet4--------------------------------------------------------
data(wastewater_data, package = "DSIWastewater")

workset4_data <- buildWorkSheet4(wastewater_data)

#Only show Site with more than 180 measurements for vignette for brevity
workset4_data <- workset4_data[workset4_data$n >= 180,]

## ----run regression analysis--------------------------------------------------
reg_estimates_data <- buildRegressionEstimateTable(workset4_data)
head(reg_estimates_data)

## ----make DHS plot, fig.height=15,fig.width=14.25-----------------------------
createDHSMethod_Plot(reg_estimates_data, workset4_data)

## ----Show Madison Version of The Data, fig.height=5, fig.width = 7.3----------
reg_estimates_Reduced_data <- reg_estimates_data[
                                reg_estimates_data$WWTP == "Madison MSD WWTF",
                                ]

workset4_Reduced_data <- workset4_data[
                              workset4_data$WWTP == "Madison MSD WWTF",
                              ]

createDHSMethod_Plot(reg_estimates_Reduced_data, workset4_Reduced_data)

