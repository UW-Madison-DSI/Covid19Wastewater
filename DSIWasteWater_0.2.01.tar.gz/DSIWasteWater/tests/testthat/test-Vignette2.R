test_that("Test vignettes vignettes_DHSTopLevelAnalysis_Outlier produces expected output", {
  data(wastewater_data, package = "DSIWasteWater")
  DF <- wastewater_data
  
  workset4 <- buildWorkSheet4(wastewater_data)
  
  workset4 <- workset4%>% 
    filter(n >= 180)
  
  workset4_Smooth_data <- workset4_data%>%
    group_by(WWTP)%>%
    group_split()%>%
    lapply(LoessSmoothMod)%>%
    bind_rows()
  
  expect_identical(digest::digest(workset4_Smooth_data),"fee9f7483109c0fb2c7bade3e3496463")
  
  df_data <- computeJumps(workset4_Smooth_data)
  
  expect_identical(digest::digest(df_data),"fee9f7483109c0fb2c7bade3e3496463")
  
  ranked_data <- rankJumps(df_data)
  
  expect_identical(digest::digest(ranked_data),"fee9f7483109c0fb2c7bade3e3496463")
  
  ranked_quantile_data <- computeRankQuantiles(ranked_data)
  
  expect_identical(digest::digest(ranked_quantile_data),"fee9f7483109c0fb2c7bade3e3496463")
  
  classied_data <- flagOutliers(ranked_quantile_data, 9)
  
  expect_identical(digest::digest(classied_data),"fee9f7483109c0fb2c7bade3e3496463")
  
  created_data <- RemoveOutliers(classied_data)
  
  expect_identical(digest::digest(created_data),"fee9f7483109c0fb2c7bade3e3496463")
  
  reg_estimates_data <- buildRegressionEstimateTable(created_data,
                                                     RunOn = c("sars_cov2_adj_load_log10",
                                                               "sars_adj_log10_Filtered",
                                                               "Loess"))
  expect_identical(digest::digest(reg_estimates),"fee9f7483109c0fb2c7bade3e3496463")
  
  

  DHSPlot <- createDHSMethod_Plot(reg_estimates_data, created_data, 
                       PointVal = c( "sars_cov2_adj_load_log10",
                                     "sars_adj_log10_Filtered"),
                       LineVal = "Loess")
  
  
  vdiffr::expect_doppelganger("Vignette2Plot", DHSPlot)
})