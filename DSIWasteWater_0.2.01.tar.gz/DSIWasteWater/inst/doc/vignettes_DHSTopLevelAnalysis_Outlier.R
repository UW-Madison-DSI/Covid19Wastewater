## ----load packages------------------------------------------------------------
library(DSIWasteWater)
library(dplyr)

## ----create worksheet4--------------------------------------------------------
data(Data_wastewater, package = "DSIWasteWater")

workset4 <- BuildWorkSheet4(Data_wastewater)

#Only show Site with 150 measurements for vignette 
workset4 <- workset4%>% 
  filter(n >= 150)

## ----flag outlier-------------------------------------------------------------

df <- computeJumps(workset4)
df.ranked <- rankJumps(df)
df.ranked.quantile <- computeRankQuantiles(df.ranked)
df.classied <- flagOutliers(df.ranked.quantile, 9)
df.created <- RemoveOutliers(df.classied)


## ----run package code---------------------------------------------------------

reg_estimates <- BuildRegressionEstimateTable(df.created, 
                                     c("sars_cov2_adj_load_log10",
                                     "sars_adj_log10_Filtered")
                                    )
head(reg_estimates)

## ----temp explore,fig.width=6-------------------------------------------------
library(ggplot2)

ConfMatrix(reg_estimates, "Catagory", "sars_cov2_adj_load_log10", "sars_adj_log10_Filtered")


reg_estimates%>%
  group_by(Method,Catagory)%>%
  summarise(n = n())%>%
  ggplot(aes(x=Catagory,y=n))+
           geom_col(aes(fill=Method),position = "dodge")+ 
  theme(axis.text.x = element_text(angle = 90, vjust = 0.5, hjust=1))

## ----make DHS plot, fig.height=8,fig.width=78---------------------------------
#TODO restructure so it can accept 2 point vars
#underlying function can already do this, just not the wrapper
DHSTopLevelPlots(reg_estimates, df.created, 
                 PointVal = c( "sars_cov2_adj_load_log10","sars_adj_log10_Filtered"))

